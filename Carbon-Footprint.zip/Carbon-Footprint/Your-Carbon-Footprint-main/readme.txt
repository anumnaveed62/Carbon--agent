install streamlit
pip install streamlit


streamlit run app2.py